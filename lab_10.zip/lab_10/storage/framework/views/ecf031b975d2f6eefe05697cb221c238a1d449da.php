<?php $__env->startSection("title"); ?><?php echo e($item->name); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection("path"); ?>../<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<section id="info">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="row">
                    <div class="col-12">
                        <h1><?php echo e($item->name); ?></h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7">
                        <img src="../<?php echo e($item->image); ?>">
                    </div>
                    <div class="col-lg-5 d-flex flex-column">
                        <div class="d-flex flex-row justify-content-center justify-content-lg-start">
                            <p class="mr-3">Бренд: <?php echo e($item->brand); ?></p>
                            <p>  Код товару: <?php echo e($item->code); ?></p>
                        </div>
                        <div class="d-flex flex-row justify-content-center justify-content-lg-start">
                            <p class="mb-3">Виберіть розмір:</p>
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-lg-10 col-sm-6 col-8 p_border">
                                <p>Рама S (зріст 160 - 170 см) </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-11 pr-lg-0 d-flex flex-row justify-content-between align-items-baseline">
                                <p class="price">Ціна: <?php echo e($item->price); ?> грн</p>
                                <a href="#">Купити </a>
                            </div>
                        </div>
                        <p>Гарантія: 2 роки</p>
                        <div class="d-flex flex-row flex-wrap justify-content-between align-items-center mt-3">
                            <div class="d-flex flex-row payment">
                                <img src="../images/payment1.png">
                                <div class="d-flex flex-column">
                                    <p>Оплата частинами</p>
                                    <p class="grey">до 7 платежів - <?php echo e(intval(intval($item->price)/7)); ?> грн/міс</p>
                                </div>
                            </div>
                            <div class="d-flex flex-ro payment">
                                <img src="../images/payment2.png">
                                <div class="d-flex flex-column">
                                    <p>Оплата частинами</p>
                                    <p class="grey">до 10 платежів - <?php echo e(intval($item->price)/10); ?> грн/міс</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">

            <div class="col-md-10">
                <div class="row">

                    <style>
                        .comment {
                            font-family: "MyriadPro-Regular";
                            margin-top: 80px;
                            margin-bottom: 50px;
                            padding-left: 15px;
                        }
                        .comment_name {
                            font-size: 20px;
                            border: 2px solid #666;
                            border-radius: 4px 4px 0 0;
                            padding: 8px;
                            font-weight: bold;
                        }
                        .comment_text {
                            font-size: 20px;
                            padding: 15px;
                            margin-bottom: 20px;
                            border: 2px solid #666;
                            border-top: none;
                        }
                        .stitle {
                            font-size: 30px;
                            border-bottom: 1px solid #a67c52;
                            margin-bottom: 15px;
                            padding-bottom: 5px;
                        }
                        .comment input[type="text"], .comment textarea {
                            font-size: 20px;
                            margin-bottom: 5px;
                            padding: 5px;
                            border: none;
                            border-bottom: 2px solid #F7931E;
                            background-color: rgba(255,255,255,.825);
                        }
                        .comment input[type="submit"]{
                            font-size: 20px;
                            padding: 10px 50px;
                            background-color: #F7931E;
                            border: 1px solid #000;
                        }
                        .comment input[type="submit"]:hover{
                            background-color: #fff;
                            border: 1px solid #F7931E;
                            color: #F7931E;
                        }
                    </style>


                    <div class="col comment">
                        <div class="stitle">Коментарі</div>


                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment_name">
                                <?php echo e($item["name"]); ?>

                            </div>
                            <div class="comment_text">
                                <?php echo e($item["text"]); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <form action="../addComment" method="post" class="comment_form">
                            <?php echo csrf_field(); ?>
                            <input required type="text" name="name" placeholder="Ім'я"><br/>
                            <textarea required placeholder="Повідомлення" name="text" class="col-8"></textarea><br/>
                            <input type="submit" value="Відправити">
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\wampstack-7.3.18-0\apache2\htdocs\lab_10\resources\views/info.blade.php ENDPATH**/ ?>