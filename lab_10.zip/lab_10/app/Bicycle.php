<?php

namespace App;



class Bicycle {

    public $brand, $name, $price, $code, $image;

    function __construct($id = -1){
        $db = Data::$database;

        $this->brand = $db[$id]["brand"];
        $this->name = $db[$id]["name"];
        $this->price = $db[$id]["price"];
        $this->code = $db[$id]["code"];
        $this->image = $db[$id]["image"];
    }

}
