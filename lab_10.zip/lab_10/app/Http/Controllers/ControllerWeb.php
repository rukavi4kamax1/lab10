<?php


namespace App\Http\Controllers;


use App\Bicycle;
use App\Data;
use Illuminate\Http\Request;

class ControllerWeb extends Controller {

    function welcome(){
        return view('welcome');
    }

    function catalog() {
        $count = sizeof(Data::$database);
        $catalog = [];
        for ( $i = 0; $i < $count; $i++)
            array_push ($catalog, new Bicycle($i));
        return view('catalog',["catalog" => $catalog]);
    }

    function infopage($id){
        $dbsize = sizeof(Data::$database);
        $id = intval($id);
        if ($id >= 0 && $id < $dbsize) {
            $fd = fopen("comments.txt", 'r');
            $comments = [];
            while(!feof($fd))
                array_push($comments,["name" => fgets($fd), "text" => fgets($fd)] );
            array_pop($comments);
            return view('info', ["item" => new Bicycle($id), "comments" => $comments]);
        }
        else
            return redirect('');
    }

    function addComment(Request $request) {
        $fp = fopen("comments.txt", 'a');
        $name = $request->input("name");
        $text = str_ireplace("\n"," ", $request->input("text"));
        $str = "$name\n$text\n";
        fwrite($fp,$str);
        return back();
    }


}
