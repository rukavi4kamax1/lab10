<?php


namespace App;


class Data {
    public static $database = [
        [
            "brand" => "Pride",
            "name" => "Велосипед 28\" Pride RoCX TOUR (2020)",
            "price" => "23500",
            "code" => "SKD-15-16",
            "image" => "images/image1.jpg",
        ],
        [
            "brand" => "Hercules",
            "name" => "Велосипед Hercules Uno R7 - 2019 - 28",
            "price" => "15630",
            "code" => "SKU-63-98",
            "image" => "images/image2.jpg",
        ],
        [
            "brand" => "COMFORT",
            "name" => "Велосипед COMFORT Note F29",
            "price" => "18690",
            "code" => "SKT-35-87",
            "image" => "images/image3.jpg",
        ],
        [
            "brand" => "Winora",
            "name" => "Велосипед Winora Holiday N7",
            "price" => "13900",
            "code" => "SKU-87-45",
            "image" => "images/image4.jpg",
        ],
        [
            "brand" => "Pride",
            "name" => "Велосипед PRIDE Rocx Flb 8.1",
            "price" => "12800",
            "code" => "SKD-85-32",
            "image" => "images/image5.jpg",
        ],
        [
            "brand" => "Pride",
            "name" => "Велосипед PRIDE Marvel 6.3 2019",
            "price" => "9850",
            "code" => "SKD-25-65",
            "image" => "images/image6.jpg",
        ]
    ];
}
